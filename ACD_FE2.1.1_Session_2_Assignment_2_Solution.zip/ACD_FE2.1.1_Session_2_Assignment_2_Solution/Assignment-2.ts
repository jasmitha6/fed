

// creating  a class with teachername and _standard as a private property 
class FavTeacher {
  private _teacherName: string;
  private _standard: number;

  constructor(teacheName: string, standard : number){
    this._teacherName = teacheName;
    this._standard = standard
  }
// below function is returning teachername and _standard
  getTeacherName(): string {
    return `My fav teacher name is ${this._teacherName} and she used to teach us in ${this._standard}`
  }
}
// calling getTeacherName function and printing the value in the console.
let teacheName = new FavTeacher("Rashmi", 4);
console.log(teacheName.getTeacherName())

